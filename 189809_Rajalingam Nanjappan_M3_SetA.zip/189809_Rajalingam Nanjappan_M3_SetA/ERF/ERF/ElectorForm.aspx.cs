﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ERF.ServiceReference1;
using ERF_WcfService;

namespace ERF
{
    public partial class ElectorForm : System.Web.UI.Page
    {
        ElectorSeviceClient Client = new ElectorSeviceClient();

        public ElectorForm()
        {
            Client = new ElectorSeviceClient();
        }

        protected void btn_register_Click(object sender, EventArgs e)
        {

            try
            {
                Elector ele = new Elector
                {
                    
                    ElectorName = txt_name.Text,
                    Gender = Gender.Text,
                    DOB = Convert.ToDateTime(txt_dob.Text),
                    MobileNo = txt_mobno.Text,
                    EmailAddress = txt_eaddress.Text,
                    Address = txt_address.Text,
                    AgeProof = dd_ageproof.SelectedItem.Text,
                    AddressProof = dd_addressproof.SelectedItem.Text,
                    };
             Client.Add
                    (new Elector { ElectorName = ele.ElectorName,
                        Gender = ele.Gender,
                        DOB = ele.DOB,
                        MobileNo = ele.MobileNo,
                        EmailAddress = ele.EmailAddress,
                        Address = ele.Address,
                        AgeProof = ele.AgeProof,
                        AddressProof = ele.AddressProof
                       });
                ScriptManager.RegisterStartupScript(this, this.GetType(), "ERF", "alert('Elector Inserted Successfully!')", true);
                
            }
            catch (Exception ex)
            {

                ScriptManager.RegisterStartupScript(this, this.GetType(), "ERF-Error", "alert('" + ex.Message + "')", true);
            }
        }

        protected void dd_ageproof_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void dd_addressproof_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

       
    }
}