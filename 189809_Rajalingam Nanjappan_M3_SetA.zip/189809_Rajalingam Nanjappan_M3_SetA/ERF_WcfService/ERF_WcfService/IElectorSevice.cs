﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ERF_WcfService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IElectorSevice
    {
        [OperationContract]
        void Add(Elector elector);

        


    }

    // Use a data contract as illustrated in the sample below to add composite types to service operations.
    // You can add XSD files into the project. After building the project, you can directly use the data types defined there, with the namespace "ERF_WcfService.ContractType".
    [DataContract]
    public class Elector
    {
        private int electorId;
        [DataMember]
        public int ElectorID
        {
            get { return electorId; }
            set { electorId = value; }
        }

        private string elctorname;
        [DataMember]
        public string ElectorName
        {
            get { return elctorname; }
            set { elctorname = value; }
        }

        private DateTime dob;
        [DataMember]
        public DateTime DOB
        {
            get { return dob; }
            set { dob = value; }
        }

        private string gender;
        [DataMember]
        public string Gender
        {
            get { return gender; }
            set { gender = value; }
        }


        private string mobileno;
        [DataMember]
        public string MobileNo
        {
            get { return mobileno; }
            set { mobileno = value; }
        }

        private string address;
        [DataMember]
        public string Address
        {
            get { return address; }
            set { address = value; }
        }

        private string emailaddress;
        [DataMember]
        public string EmailAddress
        {
            get { return emailaddress; }
            set { emailaddress = value; }
        }

        private string ageproof;
        [DataMember]
        public string AgeProof
        {
            get { return ageproof; }
            set { ageproof = value; }
        }


        private string addressproof;
        [DataMember]
        public string AddressProof
        {
            get { return addressproof; }
            set { addressproof = value; }
        }




    }
}
