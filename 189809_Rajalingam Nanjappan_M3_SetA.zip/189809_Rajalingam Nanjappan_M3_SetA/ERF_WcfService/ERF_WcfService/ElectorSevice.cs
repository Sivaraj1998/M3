﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;

namespace ERF_WcfService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in both code and config file together.
    public class ElectorSevice : IElectorSevice
    {
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public ElectorSevice()
        {
            cn = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
        }

        public void Add(Elector elector)
        {

            try
            {
                cmd = new SqlCommand("insert into r189809.Elector(ElectorName,Gender,DOB,MobileNo,EmailAddress,Address,AgeProof,AddressProof) Values(@elename,@gender,@dob,@mobno,@eaddress,@address,@ageproof,@addressproof)", cn);
                cmd.Parameters.AddWithValue("@elename", elector.ElectorName);
                cmd.Parameters.AddWithValue("@gender", elector.Gender);
                cmd.Parameters.AddWithValue("@dob", elector.DOB);
                cmd.Parameters.AddWithValue("@mobno", elector.MobileNo);
                cmd.Parameters.AddWithValue("@eaddress", elector.EmailAddress);
                cmd.Parameters.AddWithValue("@address", elector.Address);
                cmd.Parameters.AddWithValue("@ageproof", elector.AgeProof);
                cmd.Parameters.AddWithValue("@addressproof", elector.AddressProof);

                cn.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
        }

    }   
}
