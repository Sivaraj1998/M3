﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ERF_MVC.Models;

namespace ERF_MVC.Controllers
{
    public class ElectorController : Controller
    {
        Training_18Jul19_PuneEntities obj = new Training_18Jul19_PuneEntities();
        // GET: Elector
        public ActionResult Index()
        {
            return View(obj.Electors.ToList());
        }

        public ActionResult Ageproof()
        {
            var Age = from elector in obj.Electors
                      where (elector.AgeProof == "Birth Certificate" && elector.DOB.Value.Year == 1999)
                      orderby elector.ElectorName ascending
                      select elector;
            return View(Age);
        }
    }
}